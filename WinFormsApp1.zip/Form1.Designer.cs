﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pacman = new System.Windows.Forms.PictureBox();
            this.yellowGhost = new System.Windows.Forms.PictureBox();
            this.redGhost = new System.Windows.Forms.PictureBox();
            this.blueGhost = new System.Windows.Forms.PictureBox();
            this.pinkGhost = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox55 = new System.Windows.Forms.PictureBox();
            this.pictureBox62 = new System.Windows.Forms.PictureBox();
            this.pictureBox69 = new System.Windows.Forms.PictureBox();
            this.pictureBox70 = new System.Windows.Forms.PictureBox();
            this.pictureBox76 = new System.Windows.Forms.PictureBox();
            this.pictureBox77 = new System.Windows.Forms.PictureBox();
            this.pictureBox78 = new System.Windows.Forms.PictureBox();
            this.pictureBox100 = new System.Windows.Forms.PictureBox();
            this.pictureBox123 = new System.Windows.Forms.PictureBox();
            this.pictureBox138 = new System.Windows.Forms.PictureBox();
            this.pictureBox148 = new System.Windows.Forms.PictureBox();
            this.pictureBox154 = new System.Windows.Forms.PictureBox();
            this.pictureBox155 = new System.Windows.Forms.PictureBox();
            this.pictureBox157 = new System.Windows.Forms.PictureBox();
            this.pictureBox158 = new System.Windows.Forms.PictureBox();
            this.pictureBox159 = new System.Windows.Forms.PictureBox();
            this.pictureBox160 = new System.Windows.Forms.PictureBox();
            this.pictureBox166 = new System.Windows.Forms.PictureBox();
            this.pictureBox171 = new System.Windows.Forms.PictureBox();
            this.pictureBox172 = new System.Windows.Forms.PictureBox();
            this.pictureBox173 = new System.Windows.Forms.PictureBox();
            this.pictureBox174 = new System.Windows.Forms.PictureBox();
            this.pictureBox183 = new System.Windows.Forms.PictureBox();
            this.pictureBox206 = new System.Windows.Forms.PictureBox();
            this.pictureBox227 = new System.Windows.Forms.PictureBox();
            this.pictureBox232 = new System.Windows.Forms.PictureBox();
            this.pictureBox39 = new System.Windows.Forms.PictureBox();
            this.pictureBox42 = new System.Windows.Forms.PictureBox();
            this.pictureBox235 = new System.Windows.Forms.PictureBox();
            this.pictureBox240 = new System.Windows.Forms.PictureBox();
            this.pictureBox241 = new System.Windows.Forms.PictureBox();
            this.pictureBox242 = new System.Windows.Forms.PictureBox();
            this.pictureBox244 = new System.Windows.Forms.PictureBox();
            this.pictureBox246 = new System.Windows.Forms.PictureBox();
            this.pictureBox247 = new System.Windows.Forms.PictureBox();
            this.pictureBox249 = new System.Windows.Forms.PictureBox();
            this.pictureBox250 = new System.Windows.Forms.PictureBox();
            this.pictureBox251 = new System.Windows.Forms.PictureBox();
            this.pictureBox258 = new System.Windows.Forms.PictureBox();
            this.pictureBox259 = new System.Windows.Forms.PictureBox();
            this.pictureBox260 = new System.Windows.Forms.PictureBox();
            this.pictureBox261 = new System.Windows.Forms.PictureBox();
            this.pictureBox262 = new System.Windows.Forms.PictureBox();
            this.pictureBox263 = new System.Windows.Forms.PictureBox();
            this.pictureBox264 = new System.Windows.Forms.PictureBox();
            this.pictureBox265 = new System.Windows.Forms.PictureBox();
            this.pictureBox266 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.pictureBox54 = new System.Windows.Forms.PictureBox();
            this.pictureBox56 = new System.Windows.Forms.PictureBox();
            this.pictureBox57 = new System.Windows.Forms.PictureBox();
            this.pictureBox58 = new System.Windows.Forms.PictureBox();
            this.pictureBox59 = new System.Windows.Forms.PictureBox();
            this.pictureBox60 = new System.Windows.Forms.PictureBox();
            this.pictureBox63 = new System.Windows.Forms.PictureBox();
            this.pictureBox64 = new System.Windows.Forms.PictureBox();
            this.pictureBox65 = new System.Windows.Forms.PictureBox();
            this.pictureBox66 = new System.Windows.Forms.PictureBox();
            this.pictureBox67 = new System.Windows.Forms.PictureBox();
            this.pictureBox68 = new System.Windows.Forms.PictureBox();
            this.pictureBox71 = new System.Windows.Forms.PictureBox();
            this.pictureBox72 = new System.Windows.Forms.PictureBox();
            this.pictureBox73 = new System.Windows.Forms.PictureBox();
            this.pictureBox74 = new System.Windows.Forms.PictureBox();
            this.pictureBox75 = new System.Windows.Forms.PictureBox();
            this.pictureBox79 = new System.Windows.Forms.PictureBox();
            this.pictureBox80 = new System.Windows.Forms.PictureBox();
            this.pictureBox81 = new System.Windows.Forms.PictureBox();
            this.pictureBox82 = new System.Windows.Forms.PictureBox();
            this.pictureBox83 = new System.Windows.Forms.PictureBox();
            this.pictureBox124 = new System.Windows.Forms.PictureBox();
            this.pictureBox122 = new System.Windows.Forms.PictureBox();
            this.pictureBox139 = new System.Windows.Forms.PictureBox();
            this.pictureBox137 = new System.Windows.Forms.PictureBox();
            this.pictureBox134 = new System.Windows.Forms.PictureBox();
            this.pictureBox153 = new System.Windows.Forms.PictureBox();
            this.pictureBox257 = new System.Windows.Forms.PictureBox();
            this.pictureBox256 = new System.Windows.Forms.PictureBox();
            this.pictureBox255 = new System.Windows.Forms.PictureBox();
            this.pictureBox254 = new System.Windows.Forms.PictureBox();
            this.pictureBox253 = new System.Windows.Forms.PictureBox();
            this.pictureBox252 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox170 = new System.Windows.Forms.PictureBox();
            this.pictureBox131 = new System.Windows.Forms.PictureBox();
            this.pictureBox135 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pacman)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.yellowGhost)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.redGhost)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blueGhost)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pinkGhost)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox55)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox62)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox69)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox70)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox76)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox77)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox78)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox100)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox123)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox138)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox148)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox154)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox155)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox157)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox158)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox159)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox160)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox166)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox171)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox172)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox173)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox174)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox183)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox206)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox227)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox232)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox39)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox42)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox235)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox240)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox241)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox242)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox244)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox246)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox247)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox249)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox250)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox251)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox258)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox259)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox260)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox261)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox262)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox263)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox264)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox265)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox266)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox54)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox56)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox57)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox58)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox59)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox60)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox63)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox64)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox65)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox66)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox67)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox68)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox71)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox72)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox73)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox74)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox75)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox79)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox80)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox81)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox82)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox83)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox124)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox122)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox139)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox137)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox134)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox153)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox257)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox256)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox255)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox254)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox253)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox252)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox170)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox131)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox135)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            this.SuspendLayout();
            // 
            // pacman
            // 
            this.pacman.Image = global::WinFormsApp1.Properties.Resources.left;
            this.pacman.Location = new System.Drawing.Point(26, 36);
            this.pacman.Name = "pacman";
            this.pacman.Size = new System.Drawing.Size(29, 27);
            this.pacman.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pacman.TabIndex = 0;
            this.pacman.TabStop = false;
            this.pacman.Tag = "Pacman";
            this.pacman.Click += new System.EventHandler(this.Pacman_Click);
            this.pacman.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.pictureBox1_PreviewKeyDown_1);
            // 
            // yellowGhost
            // 
            this.yellowGhost.Image = global::WinFormsApp1.Properties.Resources.ghostyellow;
            this.yellowGhost.Location = new System.Drawing.Point(737, 93);
            this.yellowGhost.Name = "yellowGhost";
            this.yellowGhost.Size = new System.Drawing.Size(38, 34);
            this.yellowGhost.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.yellowGhost.TabIndex = 1;
            this.yellowGhost.TabStop = false;
            this.yellowGhost.Tag = "ghost";
            // 
            // redGhost
            // 
            this.redGhost.Image = global::WinFormsApp1.Properties.Resources.ghostred;
            this.redGhost.Location = new System.Drawing.Point(108, 170);
            this.redGhost.Name = "redGhost";
            this.redGhost.Size = new System.Drawing.Size(38, 38);
            this.redGhost.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.redGhost.TabIndex = 53;
            this.redGhost.TabStop = false;
            this.redGhost.Tag = "ghost";
            // 
            // blueGhost
            // 
            this.blueGhost.Image = global::WinFormsApp1.Properties.Resources.ghostblue;
            this.blueGhost.Location = new System.Drawing.Point(303, 237);
            this.blueGhost.Name = "blueGhost";
            this.blueGhost.Size = new System.Drawing.Size(36, 38);
            this.blueGhost.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.blueGhost.TabIndex = 54;
            this.blueGhost.TabStop = false;
            this.blueGhost.Tag = "ghost";
            // 
            // pinkGhost
            // 
            this.pinkGhost.Image = global::WinFormsApp1.Properties.Resources.ghostpink;
            this.pinkGhost.Location = new System.Drawing.Point(26, 235);
            this.pinkGhost.Name = "pinkGhost";
            this.pinkGhost.Size = new System.Drawing.Size(36, 38);
            this.pinkGhost.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pinkGhost.TabIndex = 55;
            this.pinkGhost.TabStop = false;
            this.pinkGhost.Tag = "ghost";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox1.Location = new System.Drawing.Point(658, 321);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(20, 20);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 56;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Tag = "coin";
            // 
            // pictureBox55
            // 
            this.pictureBox55.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox55.Location = new System.Drawing.Point(35, 295);
            this.pictureBox55.Name = "pictureBox55";
            this.pictureBox55.Size = new System.Drawing.Size(20, 20);
            this.pictureBox55.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox55.TabIndex = 58;
            this.pictureBox55.TabStop = false;
            this.pictureBox55.Tag = "coin";
            // 
            // pictureBox62
            // 
            this.pictureBox62.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox62.Location = new System.Drawing.Point(514, 321);
            this.pictureBox62.Name = "pictureBox62";
            this.pictureBox62.Size = new System.Drawing.Size(20, 20);
            this.pictureBox62.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox62.TabIndex = 65;
            this.pictureBox62.TabStop = false;
            this.pictureBox62.Tag = "coin";
            // 
            // pictureBox69
            // 
            this.pictureBox69.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox69.Location = new System.Drawing.Point(35, 340);
            this.pictureBox69.Name = "pictureBox69";
            this.pictureBox69.Size = new System.Drawing.Size(20, 20);
            this.pictureBox69.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox69.TabIndex = 72;
            this.pictureBox69.TabStop = false;
            this.pictureBox69.Tag = "coin";
            // 
            // pictureBox70
            // 
            this.pictureBox70.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox70.Location = new System.Drawing.Point(737, 27);
            this.pictureBox70.Name = "pictureBox70";
            this.pictureBox70.Size = new System.Drawing.Size(20, 20);
            this.pictureBox70.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox70.TabIndex = 73;
            this.pictureBox70.TabStop = false;
            this.pictureBox70.Tag = "coin";
            // 
            // pictureBox76
            // 
            this.pictureBox76.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox76.Location = new System.Drawing.Point(106, 321);
            this.pictureBox76.Name = "pictureBox76";
            this.pictureBox76.Size = new System.Drawing.Size(20, 20);
            this.pictureBox76.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox76.TabIndex = 80;
            this.pictureBox76.TabStop = false;
            this.pictureBox76.Tag = "coin";
            // 
            // pictureBox77
            // 
            this.pictureBox77.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox77.Location = new System.Drawing.Point(292, 170);
            this.pictureBox77.Name = "pictureBox77";
            this.pictureBox77.Size = new System.Drawing.Size(20, 20);
            this.pictureBox77.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox77.TabIndex = 79;
            this.pictureBox77.TabStop = false;
            this.pictureBox77.Tag = "coin";
            // 
            // pictureBox78
            // 
            this.pictureBox78.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox78.Location = new System.Drawing.Point(142, 321);
            this.pictureBox78.Name = "pictureBox78";
            this.pictureBox78.Size = new System.Drawing.Size(20, 20);
            this.pictureBox78.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox78.TabIndex = 78;
            this.pictureBox78.TabStop = false;
            this.pictureBox78.Tag = "coin";
            // 
            // pictureBox100
            // 
            this.pictureBox100.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox100.Location = new System.Drawing.Point(35, 255);
            this.pictureBox100.Name = "pictureBox100";
            this.pictureBox100.Size = new System.Drawing.Size(20, 20);
            this.pictureBox100.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox100.TabIndex = 107;
            this.pictureBox100.TabStop = false;
            this.pictureBox100.Tag = "coin";
            // 
            // pictureBox123
            // 
            this.pictureBox123.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox123.Location = new System.Drawing.Point(737, 255);
            this.pictureBox123.Name = "pictureBox123";
            this.pictureBox123.Size = new System.Drawing.Size(20, 20);
            this.pictureBox123.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox123.TabIndex = 114;
            this.pictureBox123.TabStop = false;
            this.pictureBox123.Tag = "coin";
            // 
            // pictureBox138
            // 
            this.pictureBox138.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox138.Location = new System.Drawing.Point(474, 321);
            this.pictureBox138.Name = "pictureBox138";
            this.pictureBox138.Size = new System.Drawing.Size(20, 20);
            this.pictureBox138.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox138.TabIndex = 129;
            this.pictureBox138.TabStop = false;
            this.pictureBox138.Tag = "coin";
            // 
            // pictureBox148
            // 
            this.pictureBox148.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox148.Location = new System.Drawing.Point(559, 321);
            this.pictureBox148.Name = "pictureBox148";
            this.pictureBox148.Size = new System.Drawing.Size(20, 20);
            this.pictureBox148.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox148.TabIndex = 150;
            this.pictureBox148.TabStop = false;
            this.pictureBox148.Tag = "coin";
            // 
            // pictureBox154
            // 
            this.pictureBox154.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox154.Location = new System.Drawing.Point(379, 321);
            this.pictureBox154.Name = "pictureBox154";
            this.pictureBox154.Size = new System.Drawing.Size(20, 20);
            this.pictureBox154.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox154.TabIndex = 158;
            this.pictureBox154.TabStop = false;
            this.pictureBox154.Tag = "coin";
            // 
            // pictureBox155
            // 
            this.pictureBox155.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox155.Location = new System.Drawing.Point(35, 209);
            this.pictureBox155.Name = "pictureBox155";
            this.pictureBox155.Size = new System.Drawing.Size(20, 20);
            this.pictureBox155.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox155.TabIndex = 157;
            this.pictureBox155.TabStop = false;
            this.pictureBox155.Tag = "coin";
            // 
            // pictureBox157
            // 
            this.pictureBox157.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox157.Location = new System.Drawing.Point(35, 133);
            this.pictureBox157.Name = "pictureBox157";
            this.pictureBox157.Size = new System.Drawing.Size(20, 20);
            this.pictureBox157.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox157.TabIndex = 163;
            this.pictureBox157.TabStop = false;
            this.pictureBox157.Tag = "coin";
            // 
            // pictureBox158
            // 
            this.pictureBox158.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox158.Location = new System.Drawing.Point(431, 321);
            this.pictureBox158.Name = "pictureBox158";
            this.pictureBox158.Size = new System.Drawing.Size(20, 20);
            this.pictureBox158.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox158.TabIndex = 162;
            this.pictureBox158.TabStop = false;
            this.pictureBox158.Tag = "coin";
            // 
            // pictureBox159
            // 
            this.pictureBox159.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox159.Location = new System.Drawing.Point(742, 209);
            this.pictureBox159.Name = "pictureBox159";
            this.pictureBox159.Size = new System.Drawing.Size(20, 20);
            this.pictureBox159.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox159.TabIndex = 161;
            this.pictureBox159.TabStop = false;
            this.pictureBox159.Tag = "coin";
            // 
            // pictureBox160
            // 
            this.pictureBox160.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox160.Location = new System.Drawing.Point(35, 93);
            this.pictureBox160.Name = "pictureBox160";
            this.pictureBox160.Size = new System.Drawing.Size(20, 20);
            this.pictureBox160.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox160.TabIndex = 160;
            this.pictureBox160.TabStop = false;
            this.pictureBox160.Tag = "coin";
            // 
            // pictureBox166
            // 
            this.pictureBox166.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox166.Location = new System.Drawing.Point(35, 170);
            this.pictureBox166.Name = "pictureBox166";
            this.pictureBox166.Size = new System.Drawing.Size(20, 20);
            this.pictureBox166.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox166.TabIndex = 172;
            this.pictureBox166.TabStop = false;
            this.pictureBox166.Tag = "coin";
            // 
            // pictureBox171
            // 
            this.pictureBox171.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox171.Location = new System.Drawing.Point(609, 321);
            this.pictureBox171.Name = "pictureBox171";
            this.pictureBox171.Size = new System.Drawing.Size(20, 20);
            this.pictureBox171.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox171.TabIndex = 178;
            this.pictureBox171.TabStop = false;
            this.pictureBox171.Tag = "coin";
            // 
            // pictureBox172
            // 
            this.pictureBox172.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox172.Location = new System.Drawing.Point(241, 321);
            this.pictureBox172.Name = "pictureBox172";
            this.pictureBox172.Size = new System.Drawing.Size(20, 20);
            this.pictureBox172.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox172.TabIndex = 177;
            this.pictureBox172.TabStop = false;
            this.pictureBox172.Tag = "coin";
            // 
            // pictureBox173
            // 
            this.pictureBox173.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox173.Location = new System.Drawing.Point(188, 321);
            this.pictureBox173.Name = "pictureBox173";
            this.pictureBox173.Size = new System.Drawing.Size(20, 20);
            this.pictureBox173.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox173.TabIndex = 176;
            this.pictureBox173.TabStop = false;
            this.pictureBox173.Tag = "coin";
            // 
            // pictureBox174
            // 
            this.pictureBox174.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox174.Location = new System.Drawing.Point(235, 170);
            this.pictureBox174.Name = "pictureBox174";
            this.pictureBox174.Size = new System.Drawing.Size(23, 20);
            this.pictureBox174.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox174.TabIndex = 175;
            this.pictureBox174.TabStop = false;
            this.pictureBox174.Tag = "coin";
            // 
            // pictureBox183
            // 
            this.pictureBox183.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox183.Location = new System.Drawing.Point(379, 255);
            this.pictureBox183.Name = "pictureBox183";
            this.pictureBox183.Size = new System.Drawing.Size(20, 20);
            this.pictureBox183.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox183.TabIndex = 191;
            this.pictureBox183.TabStop = false;
            this.pictureBox183.Tag = "coin";
            // 
            // pictureBox206
            // 
            this.pictureBox206.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox206.Location = new System.Drawing.Point(699, 27);
            this.pictureBox206.Name = "pictureBox206";
            this.pictureBox206.Size = new System.Drawing.Size(20, 20);
            this.pictureBox206.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox206.TabIndex = 198;
            this.pictureBox206.TabStop = false;
            this.pictureBox206.Tag = "coin";
            // 
            // pictureBox227
            // 
            this.pictureBox227.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox227.Location = new System.Drawing.Point(737, 133);
            this.pictureBox227.Name = "pictureBox227";
            this.pictureBox227.Size = new System.Drawing.Size(20, 20);
            this.pictureBox227.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox227.TabIndex = 225;
            this.pictureBox227.TabStop = false;
            this.pictureBox227.Tag = "coin";
            // 
            // pictureBox232
            // 
            this.pictureBox232.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox232.Location = new System.Drawing.Point(292, 255);
            this.pictureBox232.Name = "pictureBox232";
            this.pictureBox232.Size = new System.Drawing.Size(20, 20);
            this.pictureBox232.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox232.TabIndex = 237;
            this.pictureBox232.TabStop = false;
            this.pictureBox232.Tag = "coin";
            // 
            // pictureBox39
            // 
            this.pictureBox39.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox39.Location = new System.Drawing.Point(737, 321);
            this.pictureBox39.Name = "pictureBox39";
            this.pictureBox39.Size = new System.Drawing.Size(25, 20);
            this.pictureBox39.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox39.TabIndex = 241;
            this.pictureBox39.TabStop = false;
            this.pictureBox39.Tag = "coin";
            // 
            // pictureBox42
            // 
            this.pictureBox42.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox42.Location = new System.Drawing.Point(737, 65);
            this.pictureBox42.Name = "pictureBox42";
            this.pictureBox42.Size = new System.Drawing.Size(20, 20);
            this.pictureBox42.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox42.TabIndex = 240;
            this.pictureBox42.TabStop = false;
            this.pictureBox42.Tag = "coin";
            // 
            // pictureBox235
            // 
            this.pictureBox235.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox235.Location = new System.Drawing.Point(699, 321);
            this.pictureBox235.Name = "pictureBox235";
            this.pictureBox235.Size = new System.Drawing.Size(20, 20);
            this.pictureBox235.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox235.TabIndex = 239;
            this.pictureBox235.TabStop = false;
            this.pictureBox235.Tag = "coin";
            // 
            // pictureBox240
            // 
            this.pictureBox240.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox240.Location = new System.Drawing.Point(142, 170);
            this.pictureBox240.Name = "pictureBox240";
            this.pictureBox240.Size = new System.Drawing.Size(20, 20);
            this.pictureBox240.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox240.TabIndex = 250;
            this.pictureBox240.TabStop = false;
            this.pictureBox240.Tag = "coin";
            // 
            // pictureBox241
            // 
            this.pictureBox241.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox241.Location = new System.Drawing.Point(292, 321);
            this.pictureBox241.Name = "pictureBox241";
            this.pictureBox241.Size = new System.Drawing.Size(20, 20);
            this.pictureBox241.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox241.TabIndex = 249;
            this.pictureBox241.TabStop = false;
            this.pictureBox241.Tag = "coin";
            // 
            // pictureBox242
            // 
            this.pictureBox242.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox242.Location = new System.Drawing.Point(142, 255);
            this.pictureBox242.Name = "pictureBox242";
            this.pictureBox242.Size = new System.Drawing.Size(20, 20);
            this.pictureBox242.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox242.TabIndex = 248;
            this.pictureBox242.TabStop = false;
            this.pictureBox242.Tag = "coin";
            // 
            // pictureBox244
            // 
            this.pictureBox244.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox244.Location = new System.Drawing.Point(186, 170);
            this.pictureBox244.Name = "pictureBox244";
            this.pictureBox244.Size = new System.Drawing.Size(20, 20);
            this.pictureBox244.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox244.TabIndex = 246;
            this.pictureBox244.TabStop = false;
            this.pictureBox244.Tag = "coin";
            // 
            // pictureBox246
            // 
            this.pictureBox246.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox246.Location = new System.Drawing.Point(331, 255);
            this.pictureBox246.Name = "pictureBox246";
            this.pictureBox246.Size = new System.Drawing.Size(20, 20);
            this.pictureBox246.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox246.TabIndex = 256;
            this.pictureBox246.TabStop = false;
            this.pictureBox246.Tag = "coin";
            // 
            // pictureBox247
            // 
            this.pictureBox247.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox247.Location = new System.Drawing.Point(559, 27);
            this.pictureBox247.Name = "pictureBox247";
            this.pictureBox247.Size = new System.Drawing.Size(20, 20);
            this.pictureBox247.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox247.TabIndex = 255;
            this.pictureBox247.TabStop = false;
            this.pictureBox247.Tag = "coin";
            // 
            // pictureBox249
            // 
            this.pictureBox249.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox249.Location = new System.Drawing.Point(609, 26);
            this.pictureBox249.Name = "pictureBox249";
            this.pictureBox249.Size = new System.Drawing.Size(20, 20);
            this.pictureBox249.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox249.TabIndex = 253;
            this.pictureBox249.TabStop = false;
            this.pictureBox249.Tag = "coin";
            // 
            // pictureBox250
            // 
            this.pictureBox250.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox250.Location = new System.Drawing.Point(238, 255);
            this.pictureBox250.Name = "pictureBox250";
            this.pictureBox250.Size = new System.Drawing.Size(20, 20);
            this.pictureBox250.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox250.TabIndex = 252;
            this.pictureBox250.TabStop = false;
            this.pictureBox250.Tag = "coin";
            // 
            // pictureBox251
            // 
            this.pictureBox251.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox251.Location = new System.Drawing.Point(186, 255);
            this.pictureBox251.Name = "pictureBox251";
            this.pictureBox251.Size = new System.Drawing.Size(20, 20);
            this.pictureBox251.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox251.TabIndex = 251;
            this.pictureBox251.TabStop = false;
            this.pictureBox251.Tag = "coin";
            // 
            // pictureBox258
            // 
            this.pictureBox258.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox258.Location = new System.Drawing.Point(609, 170);
            this.pictureBox258.Name = "pictureBox258";
            this.pictureBox258.Size = new System.Drawing.Size(20, 20);
            this.pictureBox258.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox258.TabIndex = 271;
            this.pictureBox258.TabStop = false;
            this.pictureBox258.Tag = "coin";
            // 
            // pictureBox259
            // 
            this.pictureBox259.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox259.Location = new System.Drawing.Point(379, 170);
            this.pictureBox259.Name = "pictureBox259";
            this.pictureBox259.Size = new System.Drawing.Size(20, 20);
            this.pictureBox259.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox259.TabIndex = 270;
            this.pictureBox259.TabStop = false;
            this.pictureBox259.Tag = "coin";
            // 
            // pictureBox260
            // 
            this.pictureBox260.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox260.Location = new System.Drawing.Point(331, 170);
            this.pictureBox260.Name = "pictureBox260";
            this.pictureBox260.Size = new System.Drawing.Size(20, 20);
            this.pictureBox260.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox260.TabIndex = 269;
            this.pictureBox260.TabStop = false;
            this.pictureBox260.Tag = "coin";
            // 
            // pictureBox261
            // 
            this.pictureBox261.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox261.Location = new System.Drawing.Point(474, 170);
            this.pictureBox261.Name = "pictureBox261";
            this.pictureBox261.Size = new System.Drawing.Size(20, 20);
            this.pictureBox261.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox261.TabIndex = 268;
            this.pictureBox261.TabStop = false;
            this.pictureBox261.Tag = "coin";
            // 
            // pictureBox262
            // 
            this.pictureBox262.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox262.Location = new System.Drawing.Point(699, 170);
            this.pictureBox262.Name = "pictureBox262";
            this.pictureBox262.Size = new System.Drawing.Size(20, 20);
            this.pictureBox262.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox262.TabIndex = 267;
            this.pictureBox262.TabStop = false;
            this.pictureBox262.Tag = "coin";
            // 
            // pictureBox263
            // 
            this.pictureBox263.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox263.Location = new System.Drawing.Point(559, 170);
            this.pictureBox263.Name = "pictureBox263";
            this.pictureBox263.Size = new System.Drawing.Size(20, 20);
            this.pictureBox263.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox263.TabIndex = 266;
            this.pictureBox263.TabStop = false;
            this.pictureBox263.Tag = "coin";
            // 
            // pictureBox264
            // 
            this.pictureBox264.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox264.Location = new System.Drawing.Point(658, 170);
            this.pictureBox264.Name = "pictureBox264";
            this.pictureBox264.Size = new System.Drawing.Size(20, 20);
            this.pictureBox264.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox264.TabIndex = 265;
            this.pictureBox264.TabStop = false;
            this.pictureBox264.Tag = "coin";
            // 
            // pictureBox265
            // 
            this.pictureBox265.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox265.Location = new System.Drawing.Point(431, 170);
            this.pictureBox265.Name = "pictureBox265";
            this.pictureBox265.Size = new System.Drawing.Size(20, 20);
            this.pictureBox265.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox265.TabIndex = 264;
            this.pictureBox265.TabStop = false;
            this.pictureBox265.Tag = "coin";
            // 
            // pictureBox266
            // 
            this.pictureBox266.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox266.Location = new System.Drawing.Point(514, 170);
            this.pictureBox266.Name = "pictureBox266";
            this.pictureBox266.Size = new System.Drawing.Size(20, 20);
            this.pictureBox266.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox266.TabIndex = 263;
            this.pictureBox266.TabStop = false;
            this.pictureBox266.Tag = "coin";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(1, 403);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 25);
            this.label1.TabIndex = 272;
            this.label1.Text = "label1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label2.Location = new System.Drawing.Point(579, 388);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 38);
            this.label2.TabIndex = 274;
            this.label2.Click += new System.EventHandler(this.label3_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 20;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // pictureBox54
            // 
            this.pictureBox54.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox54.Location = new System.Drawing.Point(331, 91);
            this.pictureBox54.Name = "pictureBox54";
            this.pictureBox54.Size = new System.Drawing.Size(20, 20);
            this.pictureBox54.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox54.TabIndex = 297;
            this.pictureBox54.TabStop = false;
            this.pictureBox54.Tag = "coin";
            // 
            // pictureBox56
            // 
            this.pictureBox56.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox56.Location = new System.Drawing.Point(379, 93);
            this.pictureBox56.Name = "pictureBox56";
            this.pictureBox56.Size = new System.Drawing.Size(20, 20);
            this.pictureBox56.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox56.TabIndex = 296;
            this.pictureBox56.TabStop = false;
            this.pictureBox56.Tag = "coin";
            // 
            // pictureBox57
            // 
            this.pictureBox57.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox57.Location = new System.Drawing.Point(431, 255);
            this.pictureBox57.Name = "pictureBox57";
            this.pictureBox57.Size = new System.Drawing.Size(20, 20);
            this.pictureBox57.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox57.TabIndex = 295;
            this.pictureBox57.TabStop = false;
            this.pictureBox57.Tag = "coin";
            // 
            // pictureBox58
            // 
            this.pictureBox58.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox58.Location = new System.Drawing.Point(658, 93);
            this.pictureBox58.Name = "pictureBox58";
            this.pictureBox58.Size = new System.Drawing.Size(20, 20);
            this.pictureBox58.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox58.TabIndex = 294;
            this.pictureBox58.TabStop = false;
            this.pictureBox58.Tag = "coin";
            // 
            // pictureBox59
            // 
            this.pictureBox59.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox59.Location = new System.Drawing.Point(287, 91);
            this.pictureBox59.Name = "pictureBox59";
            this.pictureBox59.Size = new System.Drawing.Size(20, 20);
            this.pictureBox59.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox59.TabIndex = 293;
            this.pictureBox59.TabStop = false;
            this.pictureBox59.Tag = "coin";
            // 
            // pictureBox60
            // 
            this.pictureBox60.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox60.Location = new System.Drawing.Point(658, 255);
            this.pictureBox60.Name = "pictureBox60";
            this.pictureBox60.Size = new System.Drawing.Size(20, 20);
            this.pictureBox60.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox60.TabIndex = 292;
            this.pictureBox60.TabStop = false;
            this.pictureBox60.Tag = "coin";
            // 
            // pictureBox63
            // 
            this.pictureBox63.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox63.Location = new System.Drawing.Point(609, 255);
            this.pictureBox63.Name = "pictureBox63";
            this.pictureBox63.Size = new System.Drawing.Size(20, 20);
            this.pictureBox63.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox63.TabIndex = 290;
            this.pictureBox63.TabStop = false;
            this.pictureBox63.Tag = "coin";
            // 
            // pictureBox64
            // 
            this.pictureBox64.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox64.Location = new System.Drawing.Point(514, 92);
            this.pictureBox64.Name = "pictureBox64";
            this.pictureBox64.Size = new System.Drawing.Size(20, 20);
            this.pictureBox64.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox64.TabIndex = 289;
            this.pictureBox64.TabStop = false;
            this.pictureBox64.Tag = "coin";
            // 
            // pictureBox65
            // 
            this.pictureBox65.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox65.Location = new System.Drawing.Point(474, 92);
            this.pictureBox65.Name = "pictureBox65";
            this.pictureBox65.Size = new System.Drawing.Size(20, 20);
            this.pictureBox65.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox65.TabIndex = 288;
            this.pictureBox65.TabStop = false;
            this.pictureBox65.Tag = "coin";
            // 
            // pictureBox66
            // 
            this.pictureBox66.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox66.Location = new System.Drawing.Point(431, 26);
            this.pictureBox66.Name = "pictureBox66";
            this.pictureBox66.Size = new System.Drawing.Size(20, 20);
            this.pictureBox66.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox66.TabIndex = 287;
            this.pictureBox66.TabStop = false;
            this.pictureBox66.Tag = "coin";
            // 
            // pictureBox67
            // 
            this.pictureBox67.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox67.Location = new System.Drawing.Point(188, 91);
            this.pictureBox67.Name = "pictureBox67";
            this.pictureBox67.Size = new System.Drawing.Size(20, 20);
            this.pictureBox67.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox67.TabIndex = 286;
            this.pictureBox67.TabStop = false;
            this.pictureBox67.Tag = "coin";
            // 
            // pictureBox68
            // 
            this.pictureBox68.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox68.Location = new System.Drawing.Point(431, 92);
            this.pictureBox68.Name = "pictureBox68";
            this.pictureBox68.Size = new System.Drawing.Size(20, 20);
            this.pictureBox68.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox68.TabIndex = 285;
            this.pictureBox68.TabStop = false;
            this.pictureBox68.Tag = "coin";
            // 
            // pictureBox71
            // 
            this.pictureBox71.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox71.Location = new System.Drawing.Point(658, 27);
            this.pictureBox71.Name = "pictureBox71";
            this.pictureBox71.Size = new System.Drawing.Size(20, 20);
            this.pictureBox71.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox71.TabIndex = 284;
            this.pictureBox71.TabStop = false;
            this.pictureBox71.Tag = "coin";
            // 
            // pictureBox72
            // 
            this.pictureBox72.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox72.Location = new System.Drawing.Point(559, 91);
            this.pictureBox72.Name = "pictureBox72";
            this.pictureBox72.Size = new System.Drawing.Size(20, 20);
            this.pictureBox72.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox72.TabIndex = 283;
            this.pictureBox72.TabStop = false;
            this.pictureBox72.Tag = "coin";
            // 
            // pictureBox73
            // 
            this.pictureBox73.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox73.Location = new System.Drawing.Point(737, 93);
            this.pictureBox73.Name = "pictureBox73";
            this.pictureBox73.Size = new System.Drawing.Size(20, 20);
            this.pictureBox73.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox73.TabIndex = 282;
            this.pictureBox73.TabStop = false;
            this.pictureBox73.Tag = "coin";
            // 
            // pictureBox74
            // 
            this.pictureBox74.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox74.Location = new System.Drawing.Point(108, 91);
            this.pictureBox74.Name = "pictureBox74";
            this.pictureBox74.Size = new System.Drawing.Size(20, 20);
            this.pictureBox74.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox74.TabIndex = 281;
            this.pictureBox74.TabStop = false;
            this.pictureBox74.Tag = "coin";
            // 
            // pictureBox75
            // 
            this.pictureBox75.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox75.Location = new System.Drawing.Point(704, 255);
            this.pictureBox75.Name = "pictureBox75";
            this.pictureBox75.Size = new System.Drawing.Size(20, 20);
            this.pictureBox75.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox75.TabIndex = 280;
            this.pictureBox75.TabStop = false;
            this.pictureBox75.Tag = "coin";
            // 
            // pictureBox79
            // 
            this.pictureBox79.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox79.Location = new System.Drawing.Point(238, 91);
            this.pictureBox79.Name = "pictureBox79";
            this.pictureBox79.Size = new System.Drawing.Size(20, 20);
            this.pictureBox79.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox79.TabIndex = 279;
            this.pictureBox79.TabStop = false;
            this.pictureBox79.Tag = "coin";
            // 
            // pictureBox80
            // 
            this.pictureBox80.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox80.Location = new System.Drawing.Point(609, 93);
            this.pictureBox80.Name = "pictureBox80";
            this.pictureBox80.Size = new System.Drawing.Size(20, 20);
            this.pictureBox80.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox80.TabIndex = 278;
            this.pictureBox80.TabStop = false;
            this.pictureBox80.Tag = "coin";
            // 
            // pictureBox81
            // 
            this.pictureBox81.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox81.Location = new System.Drawing.Point(737, 170);
            this.pictureBox81.Name = "pictureBox81";
            this.pictureBox81.Size = new System.Drawing.Size(20, 20);
            this.pictureBox81.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox81.TabIndex = 277;
            this.pictureBox81.TabStop = false;
            this.pictureBox81.Tag = "coin";
            // 
            // pictureBox82
            // 
            this.pictureBox82.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox82.Location = new System.Drawing.Point(142, 92);
            this.pictureBox82.Name = "pictureBox82";
            this.pictureBox82.Size = new System.Drawing.Size(20, 20);
            this.pictureBox82.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox82.TabIndex = 276;
            this.pictureBox82.TabStop = false;
            this.pictureBox82.Tag = "coin";
            // 
            // pictureBox83
            // 
            this.pictureBox83.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox83.Location = new System.Drawing.Point(699, 92);
            this.pictureBox83.Name = "pictureBox83";
            this.pictureBox83.Size = new System.Drawing.Size(20, 20);
            this.pictureBox83.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox83.TabIndex = 275;
            this.pictureBox83.TabStop = false;
            this.pictureBox83.Tag = "coin";
            // 
            // pictureBox124
            // 
            this.pictureBox124.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox124.Location = new System.Drawing.Point(108, 26);
            this.pictureBox124.Name = "pictureBox124";
            this.pictureBox124.Size = new System.Drawing.Size(20, 20);
            this.pictureBox124.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox124.TabIndex = 113;
            this.pictureBox124.TabStop = false;
            this.pictureBox124.Tag = "coin";
            // 
            // pictureBox122
            // 
            this.pictureBox122.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox122.Location = new System.Drawing.Point(142, 26);
            this.pictureBox122.Name = "pictureBox122";
            this.pictureBox122.Size = new System.Drawing.Size(20, 20);
            this.pictureBox122.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox122.TabIndex = 115;
            this.pictureBox122.TabStop = false;
            this.pictureBox122.Tag = "coin";
            // 
            // pictureBox139
            // 
            this.pictureBox139.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox139.Location = new System.Drawing.Point(241, 27);
            this.pictureBox139.Name = "pictureBox139";
            this.pictureBox139.Size = new System.Drawing.Size(20, 20);
            this.pictureBox139.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox139.TabIndex = 128;
            this.pictureBox139.TabStop = false;
            this.pictureBox139.Tag = "coin";
            // 
            // pictureBox137
            // 
            this.pictureBox137.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox137.Location = new System.Drawing.Point(559, 255);
            this.pictureBox137.Name = "pictureBox137";
            this.pictureBox137.Size = new System.Drawing.Size(20, 20);
            this.pictureBox137.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox137.TabIndex = 130;
            this.pictureBox137.TabStop = false;
            this.pictureBox137.Tag = "coin";
            // 
            // pictureBox134
            // 
            this.pictureBox134.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox134.Location = new System.Drawing.Point(270, 27);
            this.pictureBox134.Name = "pictureBox134";
            this.pictureBox134.Size = new System.Drawing.Size(20, 20);
            this.pictureBox134.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox134.TabIndex = 133;
            this.pictureBox134.TabStop = false;
            this.pictureBox134.Tag = "coin";
            // 
            // pictureBox153
            // 
            this.pictureBox153.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox153.Location = new System.Drawing.Point(188, 26);
            this.pictureBox153.Name = "pictureBox153";
            this.pictureBox153.Size = new System.Drawing.Size(20, 20);
            this.pictureBox153.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox153.TabIndex = 159;
            this.pictureBox153.TabStop = false;
            this.pictureBox153.Tag = "coin";
            // 
            // pictureBox257
            // 
            this.pictureBox257.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox257.Location = new System.Drawing.Point(331, 27);
            this.pictureBox257.Name = "pictureBox257";
            this.pictureBox257.Size = new System.Drawing.Size(20, 20);
            this.pictureBox257.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox257.TabIndex = 257;
            this.pictureBox257.TabStop = false;
            this.pictureBox257.Tag = "coin";
            // 
            // pictureBox256
            // 
            this.pictureBox256.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox256.Location = new System.Drawing.Point(514, 255);
            this.pictureBox256.Name = "pictureBox256";
            this.pictureBox256.Size = new System.Drawing.Size(20, 20);
            this.pictureBox256.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox256.TabIndex = 258;
            this.pictureBox256.TabStop = false;
            this.pictureBox256.Tag = "coin";
            // 
            // pictureBox255
            // 
            this.pictureBox255.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox255.Location = new System.Drawing.Point(474, 255);
            this.pictureBox255.Name = "pictureBox255";
            this.pictureBox255.Size = new System.Drawing.Size(20, 20);
            this.pictureBox255.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox255.TabIndex = 259;
            this.pictureBox255.TabStop = false;
            this.pictureBox255.Tag = "coin";
            // 
            // pictureBox254
            // 
            this.pictureBox254.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox254.Location = new System.Drawing.Point(514, 27);
            this.pictureBox254.Name = "pictureBox254";
            this.pictureBox254.Size = new System.Drawing.Size(20, 20);
            this.pictureBox254.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox254.TabIndex = 260;
            this.pictureBox254.TabStop = false;
            this.pictureBox254.Tag = "coin";
            // 
            // pictureBox253
            // 
            this.pictureBox253.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox253.Location = new System.Drawing.Point(474, 26);
            this.pictureBox253.Name = "pictureBox253";
            this.pictureBox253.Size = new System.Drawing.Size(20, 20);
            this.pictureBox253.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox253.TabIndex = 261;
            this.pictureBox253.TabStop = false;
            this.pictureBox253.Tag = "coin";
            // 
            // pictureBox252
            // 
            this.pictureBox252.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox252.Location = new System.Drawing.Point(379, 27);
            this.pictureBox252.Name = "pictureBox252";
            this.pictureBox252.Size = new System.Drawing.Size(20, 20);
            this.pictureBox252.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox252.TabIndex = 262;
            this.pictureBox252.TabStop = false;
            this.pictureBox252.Tag = "coin";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Blue;
            this.pictureBox2.Location = new System.Drawing.Point(1, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(19, 372);
            this.pictureBox2.TabIndex = 298;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Tag = "wall";
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Blue;
            this.pictureBox3.Location = new System.Drawing.Point(781, 3);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(17, 372);
            this.pictureBox3.TabIndex = 299;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Tag = "wall";
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.Blue;
            this.pictureBox4.Location = new System.Drawing.Point(12, 3);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(775, 18);
            this.pictureBox4.TabIndex = 300;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Tag = "wall";
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.Blue;
            this.pictureBox5.Location = new System.Drawing.Point(1, 367);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(797, 18);
            this.pictureBox5.TabIndex = 301;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Tag = "wall";
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.Color.Blue;
            this.pictureBox6.Location = new System.Drawing.Point(84, 77);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(18, 252);
            this.pictureBox6.TabIndex = 302;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.Tag = "wall";
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackColor = System.Drawing.Color.Blue;
            this.pictureBox7.Location = new System.Drawing.Point(106, 214);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(171, 18);
            this.pictureBox7.TabIndex = 303;
            this.pictureBox7.TabStop = false;
            this.pictureBox7.Tag = "wall";
            // 
            // pictureBox8
            // 
            this.pictureBox8.BackColor = System.Drawing.Color.Blue;
            this.pictureBox8.Location = new System.Drawing.Point(292, 133);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(259, 20);
            this.pictureBox8.TabIndex = 304;
            this.pictureBox8.TabStop = false;
            this.pictureBox8.Tag = "wall";
            // 
            // pictureBox170
            // 
            this.pictureBox170.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox170.Location = new System.Drawing.Point(108, 255);
            this.pictureBox170.Name = "pictureBox170";
            this.pictureBox170.Size = new System.Drawing.Size(20, 20);
            this.pictureBox170.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox170.TabIndex = 307;
            this.pictureBox170.TabStop = false;
            this.pictureBox170.Tag = "coin";
            // 
            // pictureBox131
            // 
            this.pictureBox131.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox131.Location = new System.Drawing.Point(108, 170);
            this.pictureBox131.Name = "pictureBox131";
            this.pictureBox131.Size = new System.Drawing.Size(20, 20);
            this.pictureBox131.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox131.TabIndex = 306;
            this.pictureBox131.TabStop = false;
            this.pictureBox131.Tag = "coin";
            // 
            // pictureBox135
            // 
            this.pictureBox135.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox135.Location = new System.Drawing.Point(108, 133);
            this.pictureBox135.Name = "pictureBox135";
            this.pictureBox135.Size = new System.Drawing.Size(20, 20);
            this.pictureBox135.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox135.TabIndex = 305;
            this.pictureBox135.TabStop = false;
            this.pictureBox135.Tag = "coin";
            // 
            // pictureBox9
            // 
            this.pictureBox9.BackColor = System.Drawing.Color.Blue;
            this.pictureBox9.Location = new System.Drawing.Point(84, 67);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(640, 18);
            this.pictureBox9.TabIndex = 308;
            this.pictureBox9.TabStop = false;
            this.pictureBox9.Tag = "wall";
            // 
            // pictureBox10
            // 
            this.pictureBox10.BackColor = System.Drawing.Color.Blue;
            this.pictureBox10.Location = new System.Drawing.Point(270, 214);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(445, 18);
            this.pictureBox10.TabIndex = 309;
            this.pictureBox10.TabStop = false;
            this.pictureBox10.Tag = "wall";
            // 
            // pictureBox11
            // 
            this.pictureBox11.BackColor = System.Drawing.Color.Blue;
            this.pictureBox11.Location = new System.Drawing.Point(89, 281);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(262, 20);
            this.pictureBox11.TabIndex = 310;
            this.pictureBox11.TabStop = false;
            this.pictureBox11.Tag = "wall";
            // 
            // pictureBox12
            // 
            this.pictureBox12.BackColor = System.Drawing.Color.Blue;
            this.pictureBox12.Location = new System.Drawing.Point(419, 297);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(368, 18);
            this.pictureBox12.TabIndex = 311;
            this.pictureBox12.TabStop = false;
            this.pictureBox12.Tag = "wall";
            // 
            // pictureBox13
            // 
            this.pictureBox13.Image = global::WinFormsApp1.Properties.Resources.kiddle;
            this.pictureBox13.Location = new System.Drawing.Point(331, 321);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(20, 20);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox13.TabIndex = 312;
            this.pictureBox13.TabStop = false;
            this.pictureBox13.Tag = "coin";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(799, 437);
            this.Controls.Add(this.pictureBox13);
            this.Controls.Add(this.pictureBox12);
            this.Controls.Add(this.pictureBox11);
            this.Controls.Add(this.pictureBox10);
            this.Controls.Add(this.pictureBox9);
            this.Controls.Add(this.pictureBox170);
            this.Controls.Add(this.pictureBox131);
            this.Controls.Add(this.pictureBox135);
            this.Controls.Add(this.pictureBox8);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox54);
            this.Controls.Add(this.pictureBox56);
            this.Controls.Add(this.pictureBox57);
            this.Controls.Add(this.pictureBox58);
            this.Controls.Add(this.pictureBox59);
            this.Controls.Add(this.pictureBox60);
            this.Controls.Add(this.pictureBox63);
            this.Controls.Add(this.pictureBox64);
            this.Controls.Add(this.pictureBox65);
            this.Controls.Add(this.pictureBox66);
            this.Controls.Add(this.pictureBox67);
            this.Controls.Add(this.pictureBox68);
            this.Controls.Add(this.pictureBox71);
            this.Controls.Add(this.pictureBox72);
            this.Controls.Add(this.pictureBox73);
            this.Controls.Add(this.pictureBox74);
            this.Controls.Add(this.pictureBox75);
            this.Controls.Add(this.pictureBox79);
            this.Controls.Add(this.pictureBox80);
            this.Controls.Add(this.pictureBox81);
            this.Controls.Add(this.pictureBox82);
            this.Controls.Add(this.pictureBox83);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox258);
            this.Controls.Add(this.pictureBox259);
            this.Controls.Add(this.pictureBox260);
            this.Controls.Add(this.pictureBox261);
            this.Controls.Add(this.pictureBox262);
            this.Controls.Add(this.pictureBox263);
            this.Controls.Add(this.pictureBox264);
            this.Controls.Add(this.pictureBox265);
            this.Controls.Add(this.pictureBox266);
            this.Controls.Add(this.pictureBox252);
            this.Controls.Add(this.pictureBox253);
            this.Controls.Add(this.pictureBox254);
            this.Controls.Add(this.pictureBox255);
            this.Controls.Add(this.pictureBox256);
            this.Controls.Add(this.pictureBox257);
            this.Controls.Add(this.pictureBox246);
            this.Controls.Add(this.pictureBox247);
            this.Controls.Add(this.pictureBox249);
            this.Controls.Add(this.pictureBox250);
            this.Controls.Add(this.pictureBox251);
            this.Controls.Add(this.pictureBox240);
            this.Controls.Add(this.pictureBox241);
            this.Controls.Add(this.pictureBox242);
            this.Controls.Add(this.pictureBox244);
            this.Controls.Add(this.pictureBox39);
            this.Controls.Add(this.pictureBox42);
            this.Controls.Add(this.pictureBox235);
            this.Controls.Add(this.pictureBox232);
            this.Controls.Add(this.pictureBox227);
            this.Controls.Add(this.pictureBox206);
            this.Controls.Add(this.pictureBox183);
            this.Controls.Add(this.pictureBox171);
            this.Controls.Add(this.pictureBox172);
            this.Controls.Add(this.pictureBox173);
            this.Controls.Add(this.pictureBox174);
            this.Controls.Add(this.pictureBox166);
            this.Controls.Add(this.pictureBox157);
            this.Controls.Add(this.pictureBox158);
            this.Controls.Add(this.pictureBox159);
            this.Controls.Add(this.pictureBox160);
            this.Controls.Add(this.pictureBox153);
            this.Controls.Add(this.pictureBox154);
            this.Controls.Add(this.pictureBox155);
            this.Controls.Add(this.pictureBox148);
            this.Controls.Add(this.pictureBox134);
            this.Controls.Add(this.pictureBox137);
            this.Controls.Add(this.pictureBox138);
            this.Controls.Add(this.pictureBox139);
            this.Controls.Add(this.pictureBox122);
            this.Controls.Add(this.pictureBox123);
            this.Controls.Add(this.pictureBox124);
            this.Controls.Add(this.pictureBox100);
            this.Controls.Add(this.pictureBox76);
            this.Controls.Add(this.pictureBox77);
            this.Controls.Add(this.pictureBox78);
            this.Controls.Add(this.pictureBox70);
            this.Controls.Add(this.pictureBox69);
            this.Controls.Add(this.pictureBox62);
            this.Controls.Add(this.pictureBox55);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.pinkGhost);
            this.Controls.Add(this.blueGhost);
            this.Controls.Add(this.redGhost);
            this.Controls.Add(this.yellowGhost);
            this.Controls.Add(this.pacman);
            this.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyUp);
            this.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.Form1_PreviewKeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.pacman)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.yellowGhost)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.redGhost)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blueGhost)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pinkGhost)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox55)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox62)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox69)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox70)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox76)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox77)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox78)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox100)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox123)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox138)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox148)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox154)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox155)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox157)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox158)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox159)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox160)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox166)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox171)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox172)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox173)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox174)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox183)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox206)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox227)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox232)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox39)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox42)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox235)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox240)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox241)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox242)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox244)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox246)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox247)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox249)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox250)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox251)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox258)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox259)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox260)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox261)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox262)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox263)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox264)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox265)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox266)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox54)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox56)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox57)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox58)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox59)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox60)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox63)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox64)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox65)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox66)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox67)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox68)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox71)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox72)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox73)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox74)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox75)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox79)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox80)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox81)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox82)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox83)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox124)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox122)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox139)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox137)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox134)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox153)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox257)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox256)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox255)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox254)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox253)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox252)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox170)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox131)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox135)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private PictureBox pacman;
        private PictureBox yellowGhost;
        private PictureBox redGhost;
        private PictureBox blueGhost;
        private PictureBox pinkGhost;
        private PictureBox pictureBox1;
        private PictureBox pictureBox55;
        private PictureBox pictureBox62;
        private PictureBox pictureBox69;
        private PictureBox pictureBox70;
        private PictureBox pictureBox76;
        private PictureBox pictureBox77;
        private PictureBox pictureBox78;
        private PictureBox pictureBox100;
        private PictureBox pictureBox123;
        private PictureBox pictureBox138;
        private PictureBox pictureBox148;
        private PictureBox pictureBox154;
        private PictureBox pictureBox155;
        private PictureBox pictureBox157;
        private PictureBox pictureBox158;
        private PictureBox pictureBox159;
        private PictureBox pictureBox160;
        private PictureBox pictureBox166;
        private PictureBox pictureBox171;
        private PictureBox pictureBox172;
        private PictureBox pictureBox173;
        private PictureBox pictureBox174;
        private PictureBox pictureBox183;
        private PictureBox pictureBox206;
        private PictureBox pictureBox227;
        private PictureBox pictureBox232;
        private PictureBox pictureBox39;
        private PictureBox pictureBox42;
        private PictureBox pictureBox235;
        private PictureBox pictureBox240;
        private PictureBox pictureBox241;
        private PictureBox pictureBox242;
        private PictureBox pictureBox244;
        private PictureBox pictureBox246;
        private PictureBox pictureBox247;
        private PictureBox pictureBox249;
        private PictureBox pictureBox250;
        private PictureBox pictureBox251;
        private PictureBox pictureBox258;
        private PictureBox pictureBox259;
        private PictureBox pictureBox260;
        private PictureBox pictureBox261;
        private PictureBox pictureBox262;
        private PictureBox pictureBox263;
        private PictureBox pictureBox264;
        private PictureBox pictureBox265;
        private PictureBox pictureBox266;
        private Label label1;
        private Label label2;
        private System.Windows.Forms.Timer timer1;
        private PictureBox pictureBox54;
        private PictureBox pictureBox56;
        private PictureBox pictureBox57;
        private PictureBox pictureBox58;
        private PictureBox pictureBox59;
        private PictureBox pictureBox60;
        private PictureBox pictureBox63;
        private PictureBox pictureBox64;
        private PictureBox pictureBox65;
        private PictureBox pictureBox66;
        private PictureBox pictureBox67;
        private PictureBox pictureBox68;
        private PictureBox pictureBox71;
        private PictureBox pictureBox72;
        private PictureBox pictureBox73;
        private PictureBox pictureBox74;
        private PictureBox pictureBox75;
        private PictureBox pictureBox79;
        private PictureBox pictureBox80;
        private PictureBox pictureBox81;
        private PictureBox pictureBox82;
        private PictureBox pictureBox83;
        private PictureBox pictureBox124;
        private PictureBox pictureBox122;
        private PictureBox pictureBox139;
        private PictureBox pictureBox137;
        private PictureBox pictureBox134;
        private PictureBox pictureBox153;
        private PictureBox pictureBox257;
        private PictureBox pictureBox256;
        private PictureBox pictureBox255;
        private PictureBox pictureBox254;
        private PictureBox pictureBox253;
        private PictureBox pictureBox252;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
        private PictureBox pictureBox4;
        private PictureBox pictureBox5;
        private PictureBox pictureBox6;
        private PictureBox pictureBox7;
        private PictureBox pictureBox8;
        private PictureBox pictureBox170;
        private PictureBox pictureBox131;
        private PictureBox pictureBox135;
        private PictureBox pictureBox9;
        private PictureBox pictureBox10;
        private PictureBox pictureBox11;
        private PictureBox pictureBox12;
        private PictureBox pictureBox13;
    }
}